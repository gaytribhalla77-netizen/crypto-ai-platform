'use client';
import {useState} from 'react';

export default function Home() {
  const [symbol, setSymbol] = useState('BTCUSDT');
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  async function analyze() {
    setLoading(true);
    try {
      const r = await fetch(`http://localhost:8000/api/market/${symbol}`);
      setData(await r.json());
    } finally { setLoading(false); }
  }

  return (
    <main style={{padding: 32, fontFamily: 'system-ui', maxWidth: 1000, margin: 'auto'}}>
      <h1>AI Crypto Trading Platform</h1>
      <p>Binance public market-data dashboard — live trading is OFF.</p>
      <div style={{display:'flex', gap:8, margin:'24px 0'}}>
        <input value={symbol} onChange={e=>setSymbol(e.target.value.toUpperCase())}
          style={{padding:10, flex:1}} />
        <button onClick={analyze} disabled={loading} style={{padding:'10px 18px'}}>
          {loading ? 'Analyzing…' : 'Analyze'}
        </button>
      </div>
      {data && <pre style={{background:'#111',color:'#eee',padding:20,borderRadius:12,overflow:'auto'}}>
        {JSON.stringify(data, null, 2)}
      </pre>}
    </main>
  );
}
