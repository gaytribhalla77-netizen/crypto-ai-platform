class BinanceClient:
    """Adapter boundary for official Binance APIs.

    Implement only against current official Binance documentation.
    Never expose API secrets to the browser.
    Never request withdrawal permission.
    """
    def __init__(self, api_key: str, api_secret: str, testnet: bool = True):
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet

    async def get_account(self):
        raise NotImplementedError

    async def get_ticker(self, symbol: str):
        raise NotImplementedError

    async def place_order(self, symbol: str, side: str, quantity: float):
        raise NotImplementedError
