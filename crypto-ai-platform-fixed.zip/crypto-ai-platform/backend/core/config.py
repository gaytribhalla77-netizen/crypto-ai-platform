import os
from dataclasses import dataclass

_DEV_DEFAULT_SECRET = "dev-only-insecure-secret-change-me"


@dataclass(frozen=True)
class Settings:
    live_trading: bool = os.getenv("LIVE_TRADING", "false").lower() == "true"
    paper_trading: bool = os.getenv("PAPER_TRADING", "true").lower() == "true"
    auto_opportunity_enabled: bool = os.getenv("AUTO_OPPORTUNITY_ENABLED", "false").lower() == "true"
    auto_opportunity_max_usdt: float = float(os.getenv("AUTO_OPPORTUNITY_MAX_USDT", "10"))
    stop_loss_percent: float = float(os.getenv("DEFAULT_STOP_LOSS_PERCENT", "5"))
    take_profit_percent: float = float(os.getenv("DEFAULT_TAKE_PROFIT_PERCENT", "5"))
    secret_key: str = os.getenv("JWT_SECRET_KEY", _DEV_DEFAULT_SECRET)
    access_token_minutes: int = int(os.getenv("ACCESS_TOKEN_MINUTES", "60"))
    telegram_allowed_user_ids: tuple = tuple(
        x.strip() for x in os.getenv("TELEGRAM_ALLOWED_USER_IDS", "").split(",") if x.strip()
    )
    enable_workers: bool = os.getenv("ENABLE_WORKERS", "false").lower() == "true"
    watchlist_symbols: tuple = tuple(
        x.strip().upper() for x in os.getenv("WATCHLIST_SYMBOLS", "BTCUSDT,ETHUSDT").split(",") if x.strip()
    )


settings = Settings()

if settings.live_trading and settings.secret_key == _DEV_DEFAULT_SECRET:
    # Fail closed: refuse to start with live trading on and the default dev JWT secret.
    raise RuntimeError(
        "LIVE_TRADING is true but JWT_SECRET_KEY was not set. Refusing to start "
        "with the insecure default secret in a live-trading configuration."
    )
