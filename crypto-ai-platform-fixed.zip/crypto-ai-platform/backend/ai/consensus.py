def consensus(technical: dict, news: dict, risk: dict):
    signals = []
    if technical.get("trend") == "Bullish":
        signals.append(1)
    elif technical.get("trend") == "Bearish":
        signals.append(-1)
    else:
        signals.append(0)

    if news.get("impact") == "POSITIVE":
        signals.append(1)
    elif news.get("impact") == "NEGATIVE":
        signals.append(-1)
    else:
        signals.append(0)

    score = sum(signals)
    decision = "BUY_BIAS" if score > 0 else "SELL_BIAS" if score < 0 else "NO_TRADE"
    return {"decision": decision, "score": score, "signals": signals}
