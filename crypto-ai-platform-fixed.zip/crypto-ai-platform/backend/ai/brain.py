from ai.providers.mock import MockProvider
from ai.providers.openai_provider import OpenAIProvider

class ChiefOperator:
    def __init__(self):
        self.provider = OpenAIProvider() if __import__("os").getenv("AI_API_KEY") else MockProvider()

    async def analyze(self, symbol, market, news, risk):
        result = await self.provider.analyze(
            "Analyze this crypto setup. Return decision, confidence, risk, reasons, and no-trade reasons.",
            {"symbol": symbol, "market": market, "news": news, "risk": risk}
        )
        decision = str(result.get("decision", "NO_TRADE")).upper()
        if decision not in {"BUY", "SELL", "NO_TRADE"}:
            decision = "NO_TRADE"
        result["decision"] = decision
        result["confidence"] = max(0, min(100, float(result.get("confidence", 0))))
        return result
