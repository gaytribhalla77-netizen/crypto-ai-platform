import asyncio
from ai.technical.service import technical_analysis
from ai.news.service import news_analysis
from ai.risk.service import risk_analysis

async def analyze(symbol: str):
    technical, news, risk = await asyncio.gather(
        technical_analysis(symbol),
        news_analysis(symbol),
        risk_analysis(symbol)
    )
    return {
        "symbol": symbol.upper(),
        "technical": technical,
        "news": news,
        "risk": risk,
        "decision": "REVIEW",
        "confidence": 0,
        "message": "Live public market data is connected. Trading decisions remain disabled until verified AI/risk/execution modules are configured."
    }
