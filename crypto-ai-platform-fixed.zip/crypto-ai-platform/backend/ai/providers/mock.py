from ai.providers.base import AIProvider

class MockProvider(AIProvider):
    name = "mock"

    async def analyze(self, task, context):
        return {
            "provider": self.name,
            "task": task,
            "signal": "NEUTRAL",
            "confidence": 0,
            "reason": "Provider not configured; fail-closed development response."
        }
