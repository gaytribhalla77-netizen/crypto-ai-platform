from fastapi import APIRouter, HTTPException, Depends
from ai.brain import ChiefOperator
from news.engine import NewsEngine
from trading.testnet_service import TestnetTradeService
from database.repository import PositionRepository
from auth.dependencies import get_current_user, get_db_session

router = APIRouter(prefix="/api/v06", tags=["v0.6"])
brain = ChiefOperator()
news = NewsEngine()
testnet = TestnetTradeService()


@router.get("/analyze/{symbol}")
async def analyze(symbol: str):
    from ai.technical.service import technical_analysis
    market = await technical_analysis(symbol)
    items = await news.collect(symbol)
    news_summary = await news.summarize(symbol, items)
    risk = {"risk":"UNKNOWN","status":"baseline"}
    return await brain.analyze(symbol, market, news_summary, risk)


@router.post("/testnet/order")
async def testnet_order(
    symbol: str, side: str, amount_usdt: float, price: float, quantity: float,
    balance: float, exposure: float, daily_loss_pct: float, open_positions: int,
    client_request_id: str | None = None,
    user=Depends(get_current_user),
    session=Depends(get_db_session),
):
    """The risk-gated, idempotent, exchange-filter-validated order path.
    Portfolio figures (balance/exposure/daily_loss_pct/open_positions) must
    be supplied by the caller today — there is no live portfolio-state
    service yet to fetch them from automatically."""
    try:
        return await testnet.execute(
            session=session, user_id=user.id, symbol=symbol, side=side,
            amount_usdt=amount_usdt, price=price, quantity=quantity,
            balance=balance, exposure=exposure, daily_loss_pct=daily_loss_pct,
            open_positions=open_positions, client_request_id=client_request_id,
        )
    except Exception as e:
        raise HTTPException(400, str(e))
