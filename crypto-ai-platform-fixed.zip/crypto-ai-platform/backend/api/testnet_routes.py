from fastapi import APIRouter, HTTPException, Depends
from exchanges.binance.testnet_client import BinanceTestnetClient
from auth.dependencies import get_current_user

router = APIRouter(prefix="/api/testnet", tags=["binance-testnet"])
client = BinanceTestnetClient()

@router.get("/account")
async def testnet_account(user=Depends(get_current_user)):
    try:
        return await client.account()
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))

@router.post("/order")
async def testnet_order(symbol: str, side: str, quantity: float, user=Depends(get_current_user)):
    # NOTE: this route places a raw order with no risk-engine gate and no
    # idempotency check — it exists for direct exchange-connectivity testing
    # only. Use POST /api/v06/testnet/order for a risk-gated, idempotent path.
    try:
        return await client.order(symbol, side, quantity)
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))
