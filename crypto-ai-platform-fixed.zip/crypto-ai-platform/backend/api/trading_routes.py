from fastapi import APIRouter, Depends
from trading.risk_manager.engine import risk_engine, CombinedRiskDecision
from auth.dependencies import get_current_user

router = APIRouter(prefix="/api/trading", tags=["trading"])


@router.post("/risk-check")
async def risk_check(
    side: str,
    amount_usdt: float,
    entry_price: float,
    balance: float,
    exposure: float,
    daily_loss_pct: float,
    open_positions: int,
    automatic: bool = False,
    user=Depends(get_current_user),
):
    """The single, authoritative risk decision. Combines per-trade
    (stop-loss/take-profit/auto-limit) and portfolio-level
    (exposure/daily-loss/max-positions) checks. Any route that can
    place an order must call this, not ProductionRiskManager or
    PortfolioRisk individually."""
    decision: CombinedRiskDecision = risk_engine.validate(
        side=side,
        amount_usdt=amount_usdt,
        entry_price=entry_price,
        balance=balance,
        exposure=exposure,
        daily_loss_pct=daily_loss_pct,
        open_positions=open_positions,
        automatic=automatic,
    )
    return decision.__dict__
