class PortfolioRisk:
    def __init__(self, max_exposure_pct=25.0, max_daily_loss_pct=5.0, max_positions=5):
        self.max_exposure_pct = max_exposure_pct
        self.max_daily_loss_pct = max_daily_loss_pct
        self.max_positions = max_positions

    def validate(self, balance, exposure, daily_loss_pct, open_positions, amount):
        if balance <= 0: return False, "No available balance."
        if open_positions >= self.max_positions: return False, "Maximum open positions reached."
        if daily_loss_pct >= self.max_daily_loss_pct: return False, "Daily loss limit reached."
        if (exposure + amount) / balance * 100 > self.max_exposure_pct:
            return False, "Portfolio exposure limit reached."
        return True, "OK"
