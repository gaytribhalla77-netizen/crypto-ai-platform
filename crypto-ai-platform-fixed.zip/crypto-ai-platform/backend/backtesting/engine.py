from dataclasses import dataclass

@dataclass
class BacktestResult:
    trades: int
    wins: int
    losses: int
    return_pct: float
    max_drawdown_pct: float
    profit_factor: float

def run_backtest(closes, initial=1000.0, fee_rate=0.001):
    if len(closes) < 2:
        return BacktestResult(0,0,0,0,0,0)
    equity = initial
    peak = equity
    max_dd = 0.0
    wins = losses = 0
    gross_profit = gross_loss = 0.0
    for a,b in zip(closes, closes[1:]):
        r = (b-a)/a
        pnl = equity*r - equity*fee_rate
        equity += pnl
        if pnl > 0: wins += 1; gross_profit += pnl
        elif pnl < 0: losses += 1; gross_loss += abs(pnl)
        peak = max(peak, equity)
        max_dd = max(max_dd, (peak-equity)/peak*100)
    pf = gross_profit/gross_loss if gross_loss else float("inf") if gross_profit else 0.0
    return BacktestResult(len(closes)-1,wins,losses,(equity/initial-1)*100,max_dd,pf)
