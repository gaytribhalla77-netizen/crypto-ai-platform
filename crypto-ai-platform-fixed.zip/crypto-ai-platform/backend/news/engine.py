import os
import httpx
from news.models import NewsItem
from datetime import datetime, timezone

class NewsEngine:
    """RSS/JSON news boundary. URLs can be supplied as comma-separated NEWS_FEEDS."""
    def __init__(self):
        self.feeds = [x.strip() for x in os.getenv("NEWS_FEEDS", "").split(",") if x.strip()]

    async def collect(self, asset: str):
        # Generic JSON feed support: each feed may return a list of {title,url,published_at,asset}.
        items = []
        async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
            for url in self.feeds:
                try:
                    r = await client.get(url)
                    r.raise_for_status()
                    data = r.json()
                    for x in data if isinstance(data, list) else data.get("items", []):
                        if asset.upper() in str(x.get("asset", asset)).upper():
                            items.append(NewsItem(
                                source=url,
                                title=str(x.get("title","")),
                                url=str(x.get("url","")),
                                published_at=datetime.now(timezone.utc),
                                asset=asset,
                            ))
                except Exception:
                    continue
        return items[:50]

    async def summarize(self, asset, items):
        return {
            "asset": asset.upper(),
            "count": len(items),
            "impact": "UNKNOWN" if not items else "UNASSESSED",
            "confidence": 0 if not items else 10,
            "items": [x.title for x in items[:10]]
        }
