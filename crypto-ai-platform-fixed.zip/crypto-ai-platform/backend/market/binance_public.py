import httpx

BASE = "https://api.binance.com"

async def ticker(symbol: str):
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{BASE}/api/v3/ticker/24hr", params={"symbol": symbol.upper()})
        r.raise_for_status()
        return r.json()

async def klines(symbol: str, interval: str = "1m", limit: int = 100):
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.get(f"{BASE}/api/v3/klines", params={
            "symbol": symbol.upper(), "interval": interval, "limit": limit
        })
        r.raise_for_status()
        return r.json()
