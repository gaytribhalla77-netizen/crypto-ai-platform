from fastapi import APIRouter, HTTPException, Depends
from sqlalchemy import select

from auth.security import hash_password, verify_password, create_access_token
from auth.dependencies import get_db_session
from database.models import User

router = APIRouter(prefix="/api/auth", tags=["auth"])

# Minimal auth. Production should still add: email verification, login rate
# limiting/lockout, refresh-token rotation, 2FA, CSRF protection for any
# cookie-based flow, and account recovery. This build issues short-lived
# bearer JWTs (see core.config.settings.access_token_minutes) and nothing more.


@router.post("/register")
async def register(email: str, password: str, session=Depends(get_db_session)):
    if len(password) < 12:
        raise HTTPException(400, "Password must be at least 12 characters.")
    existing = await session.execute(select(User).where(User.email == email))
    if existing.scalar_one_or_none() is not None:
        raise HTTPException(409, "Email already registered.")
    user = User(email=email, password_hash=hash_password(password), is_admin=False)
    session.add(user)
    await session.commit()
    await session.refresh(user)
    token = create_access_token(user.id, user.is_admin)
    return {"access_token": token, "token_type": "bearer"}


@router.post("/login")
async def login(email: str, password: str, session=Depends(get_db_session)):
    result = await session.execute(select(User).where(User.email == email))
    user = result.scalar_one_or_none()
    # Same error for "no such user" and "wrong password" — don't leak which one it was.
    if user is None or not verify_password(password, user.password_hash):
        raise HTTPException(401, "Invalid email or password.")
    token = create_access_token(user.id, user.is_admin)
    return {"access_token": token, "token_type": "bearer"}


@router.post("/password-hash")
async def password_hash(password: str):
    """Dev utility only — not part of the auth flow. Kept for local debugging."""
    if len(password) < 12:
        raise HTTPException(400, "Password must be at least 12 characters.")
    return {"hash": hash_password(password)}
