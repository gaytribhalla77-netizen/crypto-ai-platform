class VoiceService:
    def normalize(self, text: str):
        return " ".join(text.strip().split())

    async def handle(self, text: str):
        return {
            "input": self.normalize(text),
            "requires_confirmation": True,
            "message": "Voice command normalized; execution must use the same risk and confirmation pipeline."
        }
