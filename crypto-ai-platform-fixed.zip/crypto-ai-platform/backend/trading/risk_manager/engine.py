"""Single risk authority.

Previously this project had three independent, uncoordinated risk checks
(RiskManager, ProductionRiskManager, PortfolioRisk) wired into different
routes with no guarantee any given order path went through all of them.

RiskEngine is now the ONE object every trade-capable route must call.
It fails closed: if either the per-trade check or the portfolio-level
check disallows, the combined decision is disallowed. Nothing downstream
should call ProductionRiskManager or PortfolioRisk directly for a live
decision path — call RiskEngine.validate().
"""
from dataclasses import dataclass

from trading.risk_manager.production import ProductionRiskManager, RiskDecision
from portfolio.risk import PortfolioRisk


@dataclass
class CombinedRiskDecision:
    allowed: bool
    reason: str
    stop_loss_price: float | None = None
    take_profit_price: float | None = None


class RiskEngine:
    def __init__(self, per_trade: ProductionRiskManager | None = None,
                 portfolio: PortfolioRisk | None = None):
        self.per_trade = per_trade or ProductionRiskManager()
        self.portfolio = portfolio or PortfolioRisk()

    def validate(self, *, side: str, amount_usdt: float, entry_price: float,
                 balance: float, exposure: float, daily_loss_pct: float,
                 open_positions: int, automatic: bool = False) -> CombinedRiskDecision:
        trade_decision: RiskDecision = self.per_trade.validate(
            side, amount_usdt, entry_price, automatic
        )
        if not trade_decision.allowed:
            return CombinedRiskDecision(False, f"per-trade check failed: {trade_decision.reason}")

        portfolio_ok, portfolio_reason = self.portfolio.validate(
            balance, exposure, daily_loss_pct, open_positions, amount_usdt
        )
        if not portfolio_ok:
            return CombinedRiskDecision(False, f"portfolio check failed: {portfolio_reason}")

        return CombinedRiskDecision(
            True, "Risk checks passed (per-trade + portfolio).",
            stop_loss_price=trade_decision.stop_loss_price,
            take_profit_price=trade_decision.take_profit_price,
        )


risk_engine = RiskEngine()
