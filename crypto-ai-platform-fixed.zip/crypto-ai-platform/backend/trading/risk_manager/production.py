from dataclasses import dataclass

@dataclass
class RiskDecision:
    allowed: bool
    reason: str
    stop_loss_price: float | None = None
    take_profit_price: float | None = None

class ProductionRiskManager:
    """Fail-closed baseline risk manager.

    This module calculates protection levels but does not place live orders.
    """
    def __init__(self, stop_loss_pct=5.0, take_profit_pct=5.0, max_auto_usdt=10.0):
        self.stop_loss_pct = stop_loss_pct
        self.take_profit_pct = take_profit_pct
        self.max_auto_usdt = max_auto_usdt

    def validate(self, side, amount_usdt, entry_price, automatic=False):
        if amount_usdt <= 0:
            return RiskDecision(False, "Amount must be greater than zero.")
        if automatic and amount_usdt > self.max_auto_usdt:
            return RiskDecision(False, "Automatic opportunity limit exceeded.")
        if entry_price <= 0:
            return RiskDecision(False, "Invalid entry price.")

        if side.upper() == "BUY":
            sl = entry_price * (1 - self.stop_loss_pct / 100)
            tp = entry_price * (1 + self.take_profit_pct / 100)
        else:
            sl = entry_price * (1 + self.stop_loss_pct / 100)
            tp = entry_price * (1 - self.take_profit_pct / 100)

        return RiskDecision(True, "Risk checks passed for paper/test execution.",
                            stop_loss_price=sl, take_profit_price=tp)
