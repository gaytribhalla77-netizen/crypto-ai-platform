import uuid
from database.repository import TradeRepository, AuditRepository, DuplicateTradeRequest
from exchanges.binance.testnet_client import BinanceTestnetClient
from exchanges.binance.filters import validate_order_filters
from trading.risk_manager.engine import risk_engine
from trading.idempotency import request_key


def _parse_lot_and_notional(exchange_info: dict, symbol: str):
    for s in exchange_info.get("symbols", []):
        if s.get("symbol", "").upper() != symbol.upper():
            continue
        min_qty = max_qty = step_size = min_notional = None
        for f in s.get("filters", []):
            ftype = f.get("filterType")
            if ftype == "LOT_SIZE":
                min_qty = float(f["minQty"])
                max_qty = float(f["maxQty"])
                step_size = float(f["stepSize"])
            elif ftype in ("MIN_NOTIONAL", "NOTIONAL"):
                min_notional = float(f.get("minNotional", f.get("notional", 0)))
        if None in (min_qty, max_qty, step_size, min_notional):
            raise RuntimeError(f"Could not read LOT_SIZE/MIN_NOTIONAL filters for {symbol}.")
        return min_qty, max_qty, step_size, min_notional
    raise RuntimeError(f"Symbol {symbol} not found in exchange info.")


class TestnetTradeService:
    """The risk-gated, idempotent, filter-validated, persisted path to
    Binance testnet. This is what routes should call to place an order —
    not BinanceTestnetClient directly."""

    def __init__(self):
        self.exchange = BinanceTestnetClient()
        self.risk = risk_engine

    async def execute(
        self, *, session, user_id: int, symbol: str, side: str,
        amount_usdt: float, price: float, quantity: float,
        balance: float, exposure: float, daily_loss_pct: float,
        open_positions: int, client_request_id: str | None = None,
        automatic: bool = False,
    ):
        trades = TradeRepository(session)
        audit = AuditRepository(session)

        if not client_request_id:
            # Deterministic fallback so an accidental double-submit of the
            # exact same order (no explicit client ID) still collides,
            # rather than silently creating two trades. A client that wants
            # to legitimately repeat the same params should pass its own
            # unique client_request_id.
            client_request_id = request_key(user_id, symbol, side, amount_usdt, "auto")

        decision = self.risk.validate(
            side=side, amount_usdt=amount_usdt, entry_price=price,
            balance=balance, exposure=exposure, daily_loss_pct=daily_loss_pct,
            open_positions=open_positions, automatic=automatic,
        )
        if not decision.allowed:
            await audit.record("trade_risk_rejected", {"symbol": symbol, "reason": decision.reason}, user_id)
            raise RuntimeError(decision.reason)

        try:
            info = await self.exchange.exchange_info(symbol)
            min_qty, max_qty, step_size, min_notional = _parse_lot_and_notional(info, symbol)
        except Exception as e:
            await audit.record("trade_filter_lookup_failed", {"symbol": symbol, "error": str(e)}, user_id)
            raise RuntimeError(f"Could not validate exchange filters, refusing to trade: {e}")

        ok, reason = validate_order_filters(quantity, price, min_qty, max_qty, step_size, min_notional)
        if not ok:
            await audit.record("trade_filter_rejected", {"symbol": symbol, "reason": reason}, user_id)
            raise RuntimeError(f"Exchange filter check failed: {reason}")

        try:
            trade = await trades.create_idempotent(
                user_id=user_id, symbol=symbol.upper(), side=side.upper(),
                amount_usdt=amount_usdt, status="PENDING",
                client_request_id=client_request_id,
            )
        except DuplicateTradeRequest as e:
            await audit.record(
                "trade_duplicate_blocked",
                {"symbol": symbol, "client_request_id": client_request_id, "existing_trade_id": e.existing_trade.id},
                user_id,
            )
            # Do not resubmit to the exchange. Return the existing trade's
            # state so the caller can reconcile instead of double-ordering.
            return {"duplicate": True, "trade_id": e.existing_trade.id, "status": e.existing_trade.status}

        await trades.update_status(trade.id, "SUBMITTED")
        client_order_id = "ai_" + uuid.uuid4().hex[:24]
        try:
            result = await self.exchange.order(symbol, side, quantity, client_order_id)
        except Exception as e:
            # Response lost / network failure: state is UNKNOWN, not FAILED —
            # a human or reconciliation job must check with the exchange
            # before ever retrying, since the order may have actually gone through.
            await trades.update_status(trade.id, "UNKNOWN")
            await audit.record("trade_submit_unknown_outcome", {"trade_id": trade.id, "error": str(e)}, user_id)
            raise RuntimeError(f"Order submission outcome unknown, needs reconciliation: {e}")

        order_status = str(result.get("status", "FILLED")).upper()
        await trades.update_status(trade.id, order_status, order_id=result.get("orderId"))
        await audit.record("trade_submitted", {"trade_id": trade.id, "exchange_response": result}, user_id)
        return {"duplicate": False, "trade_id": trade.id, "status": order_status, "exchange": result}
