from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from database.models import Trade, Position, AuditEvent


class DuplicateTradeRequest(Exception):
    """Raised when a client_request_id has already been used — the caller
    must treat this as 'do not resubmit to the exchange', not as a generic
    error to retry."""
    def __init__(self, existing_trade: Trade):
        self.existing_trade = existing_trade
        super().__init__(f"Duplicate client_request_id: trade {existing_trade.id} already exists.")


class TradeRepository:
    def __init__(self, session):
        self.session = session

    async def get_by_client_request_id(self, client_request_id: str) -> Trade | None:
        result = await self.session.execute(
            select(Trade).where(Trade.client_request_id == client_request_id)
        )
        return result.scalar_one_or_none()

    async def create_idempotent(self, **kwargs) -> Trade:
        """Create a trade row, enforcing the unique client_request_id at the
        database level (not just an in-process check, which would race under
        concurrent requests). Raises DuplicateTradeRequest instead of
        silently creating a second trade."""
        existing = await self.get_by_client_request_id(kwargs["client_request_id"])
        if existing is not None:
            raise DuplicateTradeRequest(existing)
        obj = Trade(**kwargs)
        self.session.add(obj)
        try:
            await self.session.commit()
        except IntegrityError:
            # Lost a race with a concurrent identical request between the
            # check above and this commit — the unique DB constraint is the
            # real backstop. Roll back and surface the existing row.
            await self.session.rollback()
            existing = await self.get_by_client_request_id(kwargs["client_request_id"])
            raise DuplicateTradeRequest(existing) from None
        await self.session.refresh(obj)
        return obj

    async def create(self, **kwargs):
        # Back-compat shim. Prefer create_idempotent for anything that will
        # reach the exchange.
        return await self.create_idempotent(**kwargs)

    async def update_status(self, trade_id, status, order_id=None):
        values = {"status": status}
        if order_id is not None:
            values["exchange_order_id"] = str(order_id)
        await self.session.execute(update(Trade).where(Trade.id == trade_id).values(**values))
        await self.session.commit()


class PositionRepository:
    def __init__(self, session):
        self.session = session

    async def open_positions(self, user_id):
        result = await self.session.execute(
            select(Position).where(Position.user_id == user_id, Position.status == "OPEN")
        )
        return list(result.scalars().all())

    async def all_open_positions(self):
        # Used by the background position-monitor worker, which has to scan
        # across every user, not just one.
        result = await self.session.execute(select(Position).where(Position.status == "OPEN"))
        return list(result.scalars().all())


class AuditRepository:
    def __init__(self, session):
        self.session = session

    async def record(self, event_type, payload, user_id=None):
        obj = AuditEvent(user_id=user_id, event_type=event_type, payload=payload)
        self.session.add(obj)
        await self.session.commit()
        return obj
