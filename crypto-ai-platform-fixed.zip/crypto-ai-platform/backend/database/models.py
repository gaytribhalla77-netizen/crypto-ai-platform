from sqlalchemy import String, Float, Boolean, DateTime, Text, Integer
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from datetime import datetime

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = "users"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    email: Mapped[str] = mapped_column(String(320), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(255))
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)

class Trade(Base):
    __tablename__ = "trades"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    side: Mapped[str] = mapped_column(String(8))
    amount_usdt: Mapped[float] = mapped_column(Float)
    # Order lifecycle state. Not yet a DB-enforced enum (SQLite/Postgres
    # portability), but application code should only ever write one of:
    # PENDING, SUBMITTED, ACKNOWLEDGED, PARTIALLY_FILLED, FILLED,
    # CANCEL_PENDING, CANCELLED, REJECTED, EXPIRED, UNKNOWN, RECONCILING, FAILED.
    status: Mapped[str] = mapped_column(String(32), default="PENDING")
    exchange_order_id: Mapped[str | None] = mapped_column(String(128), nullable=True)
    # Idempotency key: unique per logical order request. A retried/duplicated
    # client request with the same key must be rejected before it reaches the
    # exchange — see trading.idempotency.request_key and TradeRepository.
    client_request_id: Mapped[str] = mapped_column(String(80), unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Position(Base):
    __tablename__ = "positions"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(Integer, index=True)
    symbol: Mapped[str] = mapped_column(String(32), index=True)
    side: Mapped[str] = mapped_column(String(8))
    quantity: Mapped[float] = mapped_column(Float)
    entry_price: Mapped[float] = mapped_column(Float)
    stop_loss_price: Mapped[float] = mapped_column(Float)
    take_profit_price: Mapped[float] = mapped_column(Float)
    status: Mapped[str] = mapped_column(String(16), default="OPEN")

class AuditEvent(Base):
    __tablename__ = "audit_events"
    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    event_type: Mapped[str] = mapped_column(String(64))
    payload: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
