# Roadmap

Phase 1: Web scaffold + auth + database
Phase 2: Binance market-data adapter
Phase 3: AI provider adapter + news pipeline
Phase 4: Paper trading
Phase 5: Backtesting
Phase 6: Risk manager + position monitor
Phase 7: Confirmed live trading
Phase 8: Telegram
Phase 9: Voice
Phase 10: Android
Phase 11: Multi-user SaaS
