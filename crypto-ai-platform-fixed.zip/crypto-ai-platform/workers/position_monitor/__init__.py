"""Position-monitor worker.

Previously an empty file. trading/position_worker.py::PositionWorker had the
right evaluation logic (stop-loss/take-profit/PnL) but nothing ever called
it on a schedule, so open positions were never actually watched — the
"continuously monitor every open position" requirement was written but not
running. This worker calls it on an interval and reacts when a position
hits its exit condition.
"""
import asyncio
import logging

from database.session import SessionLocal
from database.repository import PositionRepository, AuditRepository
from trading.position_worker import PositionWorker

logger = logging.getLogger("workers.position_monitor")


class PositionMonitorWorker:
    def __init__(self, interval_seconds: int = 15):
        self.interval_seconds = interval_seconds

    async def run_once(self):
        async with SessionLocal() as session:
            repo = PositionRepository(session)
            audit = AuditRepository(session)
            worker = PositionWorker(repo)
            results = await worker.tick_all()
            for r in results:
                action = r["evaluation"]["action"]
                if action == "EXIT":
                    # NOTE: this worker detects and logs the exit condition.
                    # It deliberately does not place a live exchange order —
                    # closing a position automatically is a trading action
                    # and must go through the same risk-engine + idempotency
                    # path as any other order, which this build does not yet
                    # wire up end-to-end. Treat "EXIT" as a flagged event
                    # requiring a human or a follow-up execution job, not as
                    # confirmation that the position was actually closed.
                    logger.warning("Position %s hit exit condition: %s", r["position_id"], r["evaluation"])
                    await audit.record(
                        "position_exit_condition_detected",
                        {"position_id": r["position_id"], "symbol": r["symbol"], "evaluation": r["evaluation"]},
                    )
            return results

    async def run_forever(self):
        while True:
            try:
                await self.run_once()
            except Exception:
                logger.exception("position_monitor tick failed")
            await asyncio.sleep(self.interval_seconds)
