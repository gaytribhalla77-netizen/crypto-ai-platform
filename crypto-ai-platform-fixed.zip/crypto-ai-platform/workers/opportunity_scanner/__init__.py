"""Opportunity-scanner worker.

Previously an empty file. Ranks watchlist symbols using OpportunityEngine
against the latest market_scanner readings and surfaces candidates above a
score threshold, respecting the AUTO_OPPORTUNITY_MAX_USDT hard ceiling from
config.

Deliberately does NOT auto-execute trades. Wiring this straight into order
placement would bypass the confirmation flow the risk spec calls for
(manual trades ask for user confirmation; even "automatic opportunity"
trades are supposed to pass through the same risk engine + idempotency +
audit path as everything else, which this worker does not implement).
Candidates are only queued as notifications for a human/approval step to
act on.
"""
import asyncio
import logging

from opportunity.engine import OpportunityEngine
from core.config import settings
from workers.market_scanner import market_scanner

logger = logging.getLogger("workers.opportunity_scanner")


class OpportunityScannerWorker:
    def __init__(self, score_threshold: float = 70.0, interval_seconds: int = 30, notifier=None):
        self.engine = OpportunityEngine(settings.auto_opportunity_max_usdt)
        self.score_threshold = score_threshold
        self.interval_seconds = interval_seconds
        self.notifier = notifier  # optional NotificationWorker instance

    async def run_once(self):
        if not settings.auto_opportunity_enabled:
            return []
        candidates = []
        for symbol, reading in market_scanner.latest.items():
            # Placeholder confidence/risk/momentum mapping — there is no
            # real confidence-calibration or AI-scored risk signal wired in
            # yet (see ai/brain.py, which is a separate, unconnected path).
            trend_bullish = reading.get("trend") == "Bullish"
            confidence = 60 if trend_bullish else 30
            momentum = min(100, max(0, 50 + reading.get("change_20_candles_pct", 0)))
            risk_score = 20
            opp = self.engine.rank(symbol, confidence, risk_score, momentum)
            if opp.score >= self.score_threshold:
                candidates.append(opp)
                if self.notifier:
                    await self.notifier.enqueue(
                        "opportunity_detected", "MEDIUM",
                        {"symbol": opp.symbol, "score": opp.score, "suggested_amount_usdt": opp.suggested_amount_usdt},
                    )
        return candidates

    async def run_forever(self):
        while True:
            try:
                await self.run_once()
            except Exception:
                logger.exception("opportunity_scanner tick failed")
            await asyncio.sleep(self.interval_seconds)
